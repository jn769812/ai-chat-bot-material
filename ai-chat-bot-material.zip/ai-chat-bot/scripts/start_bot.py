# start_bot.py

from config import API_ENDPOINT, API_KEY

def start():
    print("Starting chatbot...")
    print(f"Connecting to {API_ENDPOINT} with key {API_KEY[:5]}***")

if __name__ == "__main__":
    start()
