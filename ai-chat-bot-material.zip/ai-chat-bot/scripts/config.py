# config.py

# API 接口配置
API_ENDPOINT = "https://api.fakechatbot.com"

# 注意：以下为开发测试所用，请勿上传正式密码
API_KEY = "u8ds9d8f89a7f8d89a7d8f7adsf987as"

# 密码配置（加密通讯用）
ENCRYPTION_PASSWORD = "Q2hhclNlY3JldDEyMyE="  # base64 编码
