# AI Chat Bot
A simple chatbot script using basic encryption.