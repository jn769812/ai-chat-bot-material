# Rumor Bot
A script used for spreading content on multiple platforms (for test purposes).